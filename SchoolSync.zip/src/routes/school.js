const express = require('express');
const router = express.Router();
const { createSchool, getSchool, updateSchool, inviteStaff, getStaff } = require('../controllers/schoolController');
const { authenticate, authorize } = require('../middleware/auth');

router.post('/', authenticate, authorize('admin', 'super_admin'), createSchool);
router.get('/', authenticate, getSchool);
router.put('/', authenticate, authorize('admin', 'super_admin'), updateSchool);
router.post('/invite', authenticate, authorize('admin', 'super_admin'), inviteStaff);
router.get('/staff', authenticate, authorize('admin', 'super_admin'), getStaff);

module.exports = router;